package com.example.mediacenterfkam.footballappssubs_2.Detail

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.mediacenterfkam.footballappssubs_2.*
import com.example.mediacenterfkam.footballappssubs_2.Response.MatchItem
import com.example.mediacenterfkam.footballappssubs_2.Response.TeamsItem
import com.example.mediacenterfkam.footballappssubs_2.Utils.ConvertDate
import com.example.mediacenterfkam.footballappssubs_2.Utils.invisible
import com.example.mediacenterfkam.footballappssubs_2.Utils.visible
import kotlinx.android.synthetic.main.activity_detail_match.*

class DetailMatch : AppCompatActivity(), DetailMatchView {

    lateinit var presenter: DetailMatchPresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_match)

        val item = intent.getParcelableExtra<MatchItem>("MATCH")

        setupData(item)

        presenter = DetailMatchPresenter(this)
        presenter.getTeamDetails(item.idHomeTeam!!, item.idAwayTeam!!)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = item.strHomeTeam +" vs "+ item.strAwayTeam
    }

    private fun setupData(item: MatchItem) {
        txtDetail_date.text = ConvertDate.getLongDate(item.dateEvent!!)
        tv_HomeName.text = item.strHomeTeam
        tv_AwayName.text = item.strAwayTeam
        tv_HomeScore.text = item.intHomeScore
        tv_AwayScore.text = item.intAwayScore
        tv_FormationHome.text = item.strHomeFormation
        tv_FormationAway.text = item.strAwayFormation
        tv_HomeGoals.text = item.strHomeGoalDetails
        tv_AwayGoals.text = item.strAwayGoalDetails
        tv_HomeShots.text = item.intHomeShots
        tv_AwayShots.text = item.intAwayShots
        tv_HomeGoalKeeper.text = item.strHomeLineupGoalkeeper
        tv_AwayGoalKeeper.text = item.strAwayLineupGoalkeeper
        tv_HomeDefense.text = item.strHomeLineupDefense
        tv_AwayDefens.text = item.strAwayLineupDefense
        tv_HomeMidfield.text = item.strHomeLineupMidfield
        tv_AwayMidfield.text = item.strAwayLineupMidfield
        tv_HomeForward.text = item.strHomeLineupForward
        tv_AwayForward.text = item.strAwayLineupForward
        tv_HomeSubtitutes.text = item.strHomeLineupSubstitutes
        tv_AwaySubtitutes.text = item.strAwayLineupSubstitutes

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return if (item?.itemId == android.R.id.home) {
            finish()
            true
        } else {
            return super.onOptionsItemSelected(item)
        }
    }


    override fun showLoading() {
        progressDetail.visible()
        dataView.invisible()
    }

    override fun hideLoading() {
        progressDetail.invisible()
        dataView.visible()
    }

    override fun showTeamDetails(dataHomeTeam: List<TeamsItem>, dataAwayTeam: List<TeamsItem>) {
        Glide.with(applicationContext)
            .load(dataHomeTeam[0].strTeamBadge)
            .apply(RequestOptions().placeholder(R.drawable.ic_no_data))
            .into(iv_BadgeHome)

        Glide.with(applicationContext)
            .load(dataAwayTeam[0].strTeamBadge)
            .apply(RequestOptions().placeholder(R.drawable.ic_no_data))
            .into(iv_BadgeAway)

    }
}
