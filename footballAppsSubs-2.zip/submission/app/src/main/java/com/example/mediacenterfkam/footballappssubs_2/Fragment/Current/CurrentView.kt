package com.example.mediacenterfkam.footballappssubs_2.Fragment.Current

import com.example.mediacenterfkam.footballappssubs_2.Response.MatchItem

interface CurrentView{
    fun showLoading()
    fun hideLoading()
    fun showEmptyData()
    fun showEventListPrev(data: List<MatchItem>)
}