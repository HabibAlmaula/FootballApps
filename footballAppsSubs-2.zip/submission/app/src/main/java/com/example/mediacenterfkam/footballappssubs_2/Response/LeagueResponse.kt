package com.example.mediacenterfkam.footballappssubs_2.Response

data class LeagueResponse(val leagues: List<LeaguesItem>?)
