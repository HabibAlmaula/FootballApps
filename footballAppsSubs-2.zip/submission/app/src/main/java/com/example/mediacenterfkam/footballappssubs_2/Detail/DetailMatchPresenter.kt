package com.example.mediacenterfkam.footballappssubs_2.Detail

import com.example.mediacenterfkam.footballappssubs_2.API.ApiRepository
import com.example.mediacenterfkam.footballappssubs_2.API.TheSportsDbApi
import com.example.mediacenterfkam.footballappssubs_2.Response.TeamsResponse
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class DetailMatchPresenter(val mView: DetailMatchView){
    val apiRepository = ApiRepository()
    val gson = Gson()

    fun getTeamDetails(idHomeTeam: String, idAwayTeam: String) {
        mView.showLoading()

        doAsync {
            val HomeTeam = gson.fromJson(apiRepository
                .doRequest(TheSportsDbApi.getDetailTeams(idHomeTeam)),
                TeamsResponse::class.java
            )

            val AwayTeam = gson.fromJson(apiRepository
                .doRequest(TheSportsDbApi.getDetailTeams(idAwayTeam)),
                TeamsResponse::class.java
            )

            uiThread {
                mView.hideLoading()
                mView.showTeamDetails(HomeTeam.teams!!, AwayTeam.teams!!)
            }
        }
    }
}