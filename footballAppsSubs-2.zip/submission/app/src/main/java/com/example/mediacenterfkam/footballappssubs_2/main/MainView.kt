package com.example.mediacenterfkam.footballappssubs_2.main

import com.example.mediacenterfkam.footballappssubs_2.Response.LeagueResponse

interface MainView{
    fun showLeagueList(data: LeagueResponse)
}