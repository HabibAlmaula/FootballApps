package com.example.mediacenterfkam.footballappssubs_2.main

import com.example.mediacenterfkam.footballappssubs_2.API.ApiRepository
import com.example.mediacenterfkam.footballappssubs_2.API.TheSportsDbApi
import com.example.mediacenterfkam.footballappssubs_2.Response.LeagueResponse
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class MainPresenter(val mView: MainView){
    val apiRepository = ApiRepository()
    val gson = Gson()


    fun getAllLeague(){

        doAsync {
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportsDbApi.getAllLeague()),
                LeagueResponse::class.java
            )

            uiThread {
                mView.showLeagueList(data)
            }
        }
    }


}