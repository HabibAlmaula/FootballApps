package com.example.mediacenterfkam.footballappssubs_2.Fragment.Current


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.mediacenterfkam.footballappssubs_2.*
import com.example.mediacenterfkam.footballappssubs_2.Adapter.MatchAdapter
import com.example.mediacenterfkam.footballappssubs_2.Response.MatchItem
import com.example.mediacenterfkam.footballappssubs_2.Utils.DataTransfer.RxBus
import com.example.mediacenterfkam.footballappssubs_2.Utils.DataTransfer.RxEvent
import com.example.mediacenterfkam.footballappssubs_2.Utils.invisible
import com.example.mediacenterfkam.footballappssubs_2.Utils.visible
import io.reactivex.disposables.Disposable
import kotlinx.android.synthetic.main.current_match.*


class CurrentMatch : Fragment(), CurrentView {

    lateinit var presenter: CurrentPresenter
    private lateinit var leagueDisposable: Disposable

    var events: MutableList<MatchItem> = mutableListOf()


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        presenter = CurrentPresenter(this)
        leagueDisposable = RxBus.listen(RxEvent.EventAddLeague::class.java).subscribe {
            presenter.getEventsPrev(it.leagueName)
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.current_match,container,false)
        }

    override fun showLoading() {
        progressCurrent.visible()
        rv_current.invisible()
        noData.invisible()
    }

    override fun hideLoading() {
        progressCurrent.invisible()
        rv_current.visible()
        noData.invisible()
    }

    override fun showEmptyData() {
        progressCurrent.invisible()
        rv_current.invisible()
        noData.visible()
    }

    override fun showEventListPrev(data: List<MatchItem>) {
        events.clear()
        events.addAll(data)
        val layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL,false)
        rv_current.layoutManager = layoutManager
        val adapter = MatchAdapter(events,context)
        rv_current.adapter = adapter

        adapter.notifyDataSetChanged()
        rv_current.scrollToPosition(0)

    }

}

