package com.example.mediacenterfkam.footballappssubs_2.Utils.DataTransfer


data class EventDataActivity(val data: String)
data class EventDataFragment(val data: String)