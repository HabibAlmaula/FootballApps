package com.example.mediacenterfkam.footballappssubs_2.Utils.DataTransfer


class RxEvent {
    data class EventAddLeague(val leagueName: String)
}