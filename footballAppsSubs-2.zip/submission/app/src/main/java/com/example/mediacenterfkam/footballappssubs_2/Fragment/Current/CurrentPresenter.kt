package com.example.mediacenterfkam.footballappssubs_2.Fragment.Current

import com.example.mediacenterfkam.footballappssubs_2.API.ApiRepository
import com.example.mediacenterfkam.footballappssubs_2.API.TheSportsDbApi
import com.example.mediacenterfkam.footballappssubs_2.Response.MatchResponse
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class CurrentPresenter(val mView: CurrentView){
    val apiRepository = ApiRepository()
    val gson = Gson()


    fun getEventsPrev(id: String) {
        mView.showLoading()

        doAsync {
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportsDbApi.getCurrentLeague(id)),
                MatchResponse::class.java
            )

            uiThread {
                mView.hideLoading()

                try {
                    mView.showEventListPrev(data.events!!)
                } catch (e: NullPointerException) {
                    mView.showEmptyData()
                }
            }
        }
    }
}