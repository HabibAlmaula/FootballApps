package com.example.mediacenterfkam.footballappssubs_2.main

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import com.example.mediacenterfkam.footballappssubs_2.*
import com.example.mediacenterfkam.footballappssubs_2.Adapter.ViewPagerAdapter
import com.example.mediacenterfkam.footballappssubs_2.Response.MatchItem
import com.example.mediacenterfkam.footballappssubs_2.Response.LeagueResponse
import com.example.mediacenterfkam.footballappssubs_2.Response.LeaguesItem
import com.example.mediacenterfkam.footballappssubs_2.Utils.DataTransfer.RxBus
import com.example.mediacenterfkam.footballappssubs_2.Utils.DataTransfer.RxEvent
import org.jetbrains.anko.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), MainView {
    lateinit var adapter: ViewPagerAdapter
    lateinit var presenter: MainPresenter


    lateinit var leaguesItem: LeaguesItem

    var events: MutableList<MatchItem> = mutableListOf()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        presenter = MainPresenter(this)

        presenter.getAllLeague()
        adapter = ViewPagerAdapter(supportFragmentManager)


        viewpager.adapter = adapter
        tabs.setupWithViewPager(viewpager)

    }

    override fun showLeagueList(data: LeagueResponse) {
        mainSpinner.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, data.leagues)
        mainSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                leaguesItem = mainSpinner.selectedItem as LeaguesItem

                val idLeague = leaguesItem.idLeague!!.toString()
                RxBus.publish(RxEvent.EventAddLeague(idLeague))

            }
        }
    }

}
