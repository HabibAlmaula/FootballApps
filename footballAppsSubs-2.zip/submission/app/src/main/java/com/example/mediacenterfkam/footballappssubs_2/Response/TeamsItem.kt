package com.example.mediacenterfkam.footballappssubs_2.Response

data class TeamsItem(val idTeam: String?, val strTeamBadge: String?)