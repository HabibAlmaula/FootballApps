package com.example.mediacenterfkam.footballappssubs_2.Fragment.Next


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.mediacenterfkam.footballappssubs_2.*
import com.example.mediacenterfkam.footballappssubs_2.Adapter.MatchAdapter
import com.example.mediacenterfkam.footballappssubs_2.Response.MatchItem
import com.example.mediacenterfkam.footballappssubs_2.Utils.DataTransfer.RxBus
import com.example.mediacenterfkam.footballappssubs_2.Utils.DataTransfer.RxEvent
import com.example.mediacenterfkam.footballappssubs_2.Utils.invisible
import com.example.mediacenterfkam.footballappssubs_2.Utils.visible
import io.reactivex.disposables.Disposable
import kotlinx.android.synthetic.main.next_match.*


class NextMatch : Fragment(), Nextview {
    lateinit var presenter: NextPresenter
    private lateinit var leagueDisposable: Disposable


    var events : MutableList<MatchItem> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.next_match,container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        presenter = NextPresenter(this)

        leagueDisposable = RxBus.listen(RxEvent.EventAddLeague::class.java).subscribe {
            presenter.getEventsNext(it.leagueName)
        }
    }


    override fun showLoading() {
        progressNext.visible()
        rv_next.invisible()
        noDataNext.invisible()
    }

    override fun hideLoading() {
        progressNext.invisible()
        rv_next.visible()
        noDataNext.invisible()
    }

    override fun showEmptyData() {
        progressNext.invisible()
        rv_next.invisible()
        noDataNext.visible()

    }

    override fun showEventListNext(data: List<MatchItem>) {
        events.clear()
        events.addAll(data)

        val layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        rv_next.layoutManager = layoutManager

        val adapter = MatchAdapter(events, context)
        rv_next.adapter = adapter

        adapter.notifyDataSetChanged()
        rv_next.scrollToPosition(0)
    }

}
