package com.example.mediacenterfkam.footballappssubs_2.Response

data class MatchResponse(val events: List<MatchItem>?)
