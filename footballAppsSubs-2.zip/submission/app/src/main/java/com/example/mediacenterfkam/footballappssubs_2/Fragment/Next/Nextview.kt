package com.example.mediacenterfkam.footballappssubs_2.Fragment.Next

import com.example.mediacenterfkam.footballappssubs_2.Response.MatchItem

interface Nextview{
    fun showLoading()
    fun hideLoading()
    fun showEmptyData()
    fun showEventListNext(data: List<MatchItem>)
}