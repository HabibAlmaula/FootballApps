package com.example.mediacenterfkam.footballappssubs_2.Fragment.Next

import com.example.mediacenterfkam.footballappssubs_2.API.ApiRepository
import com.example.mediacenterfkam.footballappssubs_2.API.TheSportsDbApi
import com.example.mediacenterfkam.footballappssubs_2.Response.MatchResponse
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class NextPresenter (val mView : Nextview){

    val apiRepository = ApiRepository()
    val gson = Gson()


    fun getEventsNext(id: String) {
        mView.showLoading()

        doAsync {
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportsDbApi.getNextLeague(id)),
                MatchResponse::class.java
            )

            uiThread {
                mView.hideLoading()

                try {
                    mView.showEventListNext(data.events!!)
                } catch (e: NullPointerException) {
                    mView.showEmptyData()
                }
            }
        }
    }

}